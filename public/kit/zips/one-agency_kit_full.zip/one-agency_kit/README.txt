ONE Agency brand kit
Brand kit v2.0 · Updated 2026-11-20

Digital only: RGB colour, px sizes, SVG/PNG/JPG/WebP, web fonts, MP4/GIF and HTML5.
File names follow one-agency_[asset]_[variant]_[size].[ext].

Folders
  logos/      horizontal (primary), stacked, wordmark and mark lockups (on light, on navy, navy, white), app tiles,
              favicons, social images
  colour/     the brand colour tokens as CSS and JSON
  fonts/      Unbounded (display) and Geist (body), TTF and WOFF2, with their licences
  elements/   signature devices, patterns and illustrations (on dark and on light), the Möbius loop stills
              (elements/mobius/, not in the full kit), laurel, CTA buttons, proof bar, award badge, icons
  illustrations/, textures/  glass illustrations (AI-generated in Magnific) and textures (made in code)
  references/ the nine reference ads the glass and texture style comes from
  vendor/ciq/ ConversionIQ's README for the Möbius loop, the source of its credit, and RECOLOUR.md (the Mint recolour)
  templates/  ad templates and sample ads (editable versions live in Magnific)
  ads/        the creative ads: ten concepts in four sizes, PNG and WebP (not in the full kit). Three of them
              (technology, results, vacation-ownership) are built on the Möbius loop stills.
  imagery/    photos/: the photo set, one per palette mood (credits below); the starter image
              library, AI-generated in Magnific (no real people or clients); stand-ins until real client work exists
  motion/     one-motion.js (the motion runtime), HTML5 ad sources, and exports (MP4, GIF, end frames, HTML5 ZIPs)
  copy/       the copy bank (Markdown and JSON)

Licences
  Unbounded and Geist are under the SIL Open Font License 1.1 (see fonts/*_ofl.txt).
  Logos and all other brand assets belong to ONE Agency, LLC. Use them only for ONE Agency work.
  The 2026 ARDY Award belongs to ConversionIQ.ai; say so wherever it appears.
  The Möbius loop is ConversionIQ's key visual, recoloured to Mint for ONE Agency (vendor/ciq/RECOLOUR.md): the
  stills in elements/mobius/ and the three ads in ads/ built on them. The recolour changes colour only. Never edit or
  redraw it, and credit it wherever it appears:
  "Möbius loop: ConversionIQ key visual, recoloured to Mint."

Sources
  Colour and logo: the rebrand moodboard (Figma file Ex4UgCrCeAKPnv8H6BdHMm, node 133:305, exported 2026-11-20)
  Proof figures 10M+, $100M+, 7B+, 450K+: as published on oneagency.com, November 2026.

Photo credits (imagery/photos/)
  one-agency_photo-mint-paper-waves_900x600.webp: AI-generated in Magnific, https://www.magnific.com/app/creation/Xm9WAQjBfo
  one-agency_photo-violet-silk-wave_900x507.webp: Unsplash 5Q9Gf0WSyLk, https://unsplash.com/photos/5Q9Gf0WSyLk
  one-agency_photo-violet-paper-waves_900x600.webp: AI-generated in Magnific, https://www.magnific.com/app/creation/Xm9cKPQBfo
  one-agency_photo-dark-curves_900x507.webp: Unsplash NYtHU9TLkPE, https://unsplash.com/photos/NYtHU9TLkPE
  one-agency_photo-white-layered-waves_900x600.webp: Unsplash pHUF3pNk1XA, https://unsplash.com/photos/pHUF3pNk1XA

Full kit only
  Illustrations come as PNG only here, to keep this ZIP under 100 MiB. Their WebP versions are in
  one-agency_kit_glass.zip and on the site.
  The Möbius loop stills (elements/mobius/) are in one-agency_kit_elements.zip and on the site, not here.
  The creative ads (ads/creative/) are in one-agency_kit_ads.zip and on the site, not here.
  The six 1080 px motion GIFs are in one-agency_kit_motion.zip and on the site; the MP4s here carry the same ads.
